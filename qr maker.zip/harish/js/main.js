(function($) {

  $('#reset').on('click', function(){
      $('#register-form').reset();
  });

  $('#submit').on('click', function(){
    $('#register-form').submit();
});


})(jQuery);